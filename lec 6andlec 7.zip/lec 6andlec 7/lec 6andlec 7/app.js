const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const shoppingRoutes = require('./routes/shop-routes');
const app = express();
const Type = require('./models/type');
const Product = require('./models/product');

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', 'views');

app.use('/shopping', shoppingRoutes);
app.use((req, res, next) => {
    res.render('not-found', {
        pageTitle: 'Page not found!'
    });
});



mongoose.connect('mongodb://127.0.0.1:27017/warehouse', () => {
    
    // const cosmeticCategory = new Type({
    //     title: 'Cosmetics',
    //     description: 'Cosmetics'
    // });
    // cosmeticCategory.save();
    // const pulsesCategory = new Type({
    //     title: 'Pulses',
    //     description: 'Pulses'
    // });
    // pulsesCategory.save();
    // const electronicsCategory = new Type({
    //     title: 'Electronics',
    //     description: 'Electronics'
    // });
    // electronicsCategory.save();
    
    app.listen(3000, () => {
        console.log('Started listening at port 3000.');
    });
});
